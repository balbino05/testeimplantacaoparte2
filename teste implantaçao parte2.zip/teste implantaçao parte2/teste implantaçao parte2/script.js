function fetchData() {
    const entity = document.getElementById("entitySelect").value;
    fetch(`https://swapi.dev/api/${entity}/`)
        .then(response => response.json())
        .then(data => displayData(data.results));
}

function displayData(data) {
    const resultDiv = document.getElementById("result");
    resultDiv.innerHTML = "";
    if (data.length === 0) {
        resultDiv.innerHTML = "Nenhum resultado encontrado.";
        return;
    }

    const table = document.createElement("table");
    const headers = Object.keys(data[0]);
    const headerRow = document.createElement("tr");

    headers.forEach(header => {
        const th = document.createElement("th");
        th.textContent = header;
        headerRow.appendChild(th);
    });

    table.appendChild(headerRow);

    data.forEach(item => {
        const row = document.createElement("tr");
        headers.forEach(header => {
            const cell = document.createElement("td");
            cell.textContent = item[header];
            row.appendChild(cell);
        });
        table.appendChild(row);
    });

    resultDiv.appendChild(table);
}
